import json

class Category:
    def __init__(self, name):
        self.name = name

class Product:
    def __init__(self, name, price):
        self.name = name
        self.price = price

class Amplifier(Product):
    def __init__(self, name, price, power, channels, size):
        super().__init__(name, price)
        self.power = power
        self.channels = channels
        self.size = size

class Receiver(Product):
    def __init__(self, name, price, channels, color, size):
        super().__init__(name, price)
        self.channels = channels
        self.color = color
        self.size = size

class Turntable(Product):
    def __init__(self, name, price, speed, connection_type, size):
        super().__init__(name, price)
        self.speed = speed
        self.connection_type = connection_type
        self.size = size

class Products:
    def __init__(self):
        self.products = []

    def add_product(self, produs):
        self.products.append(produs)

    def remove_product(self, produs):
        self.products.remove(produs)

    def display_products(self):
        for produs in self.products:
            print(f"{produs.name} - ${produs.price}")

class Orders:
    def __init__(self):
        self.orders = []

    def place_order(self, products, quantities, destination):
        order = {"products": products, "quantities": quantities, "destination": destination}
        self.orders.append(order)

    def display_orders(self):
        for order in self.orders:
            print(f"Order to {order['destination']}:")
            for produs, quantity in zip(order['products'], order['quantities']):
                print(f"{produs.name} - {quantity}")

def save_data(categories, products, orders):
    data = {
        "categories": [categorie.__dict__ for categorie in categories],
        "products": [produs.__dict__ for produs in products.products],
        "orders": orders.orders
    }
    return json.dumps(data)

def load_data(data_str):
    try:
        data = json.loads(data_str)
        categories = [Category(**categorie) for categorie in data.get("categories", [])]
        products = Products()
        for product_data in data.get("products", []):
            product_class = globals()[product_data["__class__"]]
            produs = product_class(**product_data)
            products.add_product(produs)
        orders = Orders()
        orders.orders = data.get("orders", [])
        return categories, products, orders
    except json.JSONDecodeError:
        print("Invalid JSON format. Loading default data.")
        return [], Products(), Orders()

def main():
    # Initialize data
    data_str = "{}"
    categories, products, orders = load_data(data_str)

    while True:
        print("\n1. Categories")
        print("2. Products")
        print("3. Orders")
        print("4. Exit")

        option = input("Enter your option: ")

        if option == "1":
            print("\n1. Add a category")
            print("2. Remove a category")
            print("3. Display all categories")

            sub_option = input("Enter your option: ")

            if sub_option == "1":
                category_name = input("Enter category name: ")
                categories.append(Category(category_name))
            elif sub_option == "2":
                category_name = input("Enter category name to remove: ")
                categories = [cat for cat in categories if cat.name != category_name]
            elif sub_option == "3":
                for categorie in categories:
                    print(categorie.name)

        elif option == "2":
            print("\n1. Add a product")
            print("2. Remove a product")
            print("3. Display all products")

            sub_option = input("Enter your option: ")

            if sub_option == "1":
                product_name = input("Enter product name: ")
                product_price = float(input("Enter product price: "))
                product_category = input("Enter product category: ")
                if any(categorie.name == product_category for categorie in categories):
                    product_class = globals()[input("Enter produs class (Amplifier, Receiver, Turntable): ")]
                    produs = product_class(product_name, product_price, **{k: input(f"Enter {k}: ") for k in product_class.__init__.__code__.co_varnames[3:]})
                    products.add_product(produs)
                else:
                    print("Invalid category!")
            elif sub_option == "2":
                product_name = input("Enter product name to remove: ")
                produs = next((p for p in products.products if p.name == product_name), None)
                if produs:
                    products.remove_product(produs)
                else:
                    print("Product not found!")
            elif sub_option == "3":
                products.display_products()

        elif option == "3":
            print("\n1. Place a new order")
            print("2. Display all orders")

            sub_option = input("Enter your option: ")

            if sub_option == "1":
                order_products = []
                order_quantities = []
                while True:
                    product_name = input("Enter product name to add to the order (type 'done' to finish): ")
                    if product_name.lower() == "done":
                        break
                    produs = next((p for p in products.products if p.name == product_name), None)
                    if produs:
                        quantity = int(input(f"Enter quantity for {product_name}: "))
                        order_products.append(produs)
                        order_quantities.append(quantity)
                    else:
                        print("Product not found!")
                order_destination = input("Enter destination address: ")
                orders.place_order(order_products, order_quantities, order_destination)
            elif sub_option == "2":
                orders.display_orders()

        elif option == "4":
            data_str = save_data(categories, products, orders)
            break

        else:
            print("Invalid option!")

if __name__ == "__main__":
    main()