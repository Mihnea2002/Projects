#include<iostream>
using namespace std;
#define size 100

class airlines
{
public:
	airlines();
	void main_menu();
	void make_reservation();
	void cancel_reservation();
	void check_ticket();
	void print_list();



private:
	struct node
	{
		string fname, lname, ID, phone_num;
		int reserve_num, seat_num;


		node *next;

	};

	node *start;

	node *temp, *temp2;

}sky;


