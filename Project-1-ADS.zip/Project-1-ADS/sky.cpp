#include <iostream>
#include <iomanip>
#include "sky.h"
#include<stdlib.h>
using namespace std;

int reserve = 999;




int seat[size];
void seat_fill()
{
	for (int i = 0; i < size; i++)
	{
		seat[i] = 0;
	}
}

bool taken=false;
bool seat_no(int y)
{

        for (int i = 0; i < size; i++ )
        {
                if( seat[i] == -1 )
                {
				taken=true;
  	                 cout << "The seat is taken already. \n";
                        cout << "Please choose another seat number from below."<<endl;

				int j = 1;
				while ( j < size+1 )
				{
					if ( seat[j-1] == -1)
					j++;
					else
					{
						cout <<"|" << j << "|";
						if ( j%10 == 0 )
						cout << endl;
						j++;
					}

                		}
		}

        }

}

void menu()
{
char choice;

do{

cout <<"\t Make Reservation    ------ [1] \n";

cout <<"\t Cancel Reservation  ------ [2] \n ";

cout <<"\t Check Ticket    -----------[3] \n";
cout <<"\t Print all pasangers ------ [4] \n";
cout <<"\t Quit                ------ [5] \n ";
cout<<endl;
cout<<"\t *Note that the information u introduced will be deleated after u close the executable\n";

cout <<"   Option : ";

	cin >> choice;
	choice = ((int)(choice)-48);

	switch (choice)
	{
	case 1: system("CLS"); sky.make_reservation();
					break;
	case 2: system("CLS"); sky.cancel_reservation();
					break;
	case 3: system("CLS"); sky.check_ticket();
					break;

	case 4: system("CLS"); sky.print_list();
					break;

	case 5: cout << "\n\nThank you come again\n\n\n";
					break;




	}	// Ending case loop.


	cout<<"\n   PROCESS COMPLETED...\n\n";

	cin.get();
	if(cin.get()=='\n')
		system("CLS");


    cout<<"\n   \xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd"<<endl;
	cout << "\t    AIRLINE RESERVATION SYSTEM \n";
	cout<<"   \xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\n"<<endl;
	cout<<"   \xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd MENU OPTIONS \xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\n"<<endl;

 }while(choice != 5 );

}

//************************************************************************
airlines::airlines()
{
	start = NULL;
}

//*************************************************************************
void airlines:: make_reservation()
{
	int meal_choice, x;


	temp = new node;

	cout<<"\n\n   Enter First Name of person: ";
	cin>>temp->fname;
	cout<<"   Enter Last Name of Person: ";
	cin>>temp->lname;
	cout<<"   Enter ID of the person: ";
	cin>>temp->ID;

	cout<<"   Enter Phone Number of Person: ";
	cin>>temp->phone_num;


	do{
	cout << "   Please Enter the Seat Number: ";

		cin>>x;
		while(x>size){
		cout<<"   Try again:: ";
		cin >>x;
		}

	cout<<endl;
		if((seat[x-1])>-1)
		taken = false;
		else
		seat_no(x);
	seat[x-1] = -1;
	temp->seat_num = x;

	}while(taken==true);


//******************************************************************************







	reserve++;
	temp->reserve_num=reserve;
	cout <<"\n   \xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\n";
	cout <<"   YOUR RESERVATION NUMBER IS :: " << reserve << "\n";
	cout <<"   \xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\xcd\n";

	temp->next = NULL;

	if(start == NULL)
		start = temp;
	else
	{
		temp2 = start;
		while (temp2->next != NULL)
		{
			temp2 = temp2->next;
		}
		temp2->next = temp;
	}

}
//********************************************************************************************
int cancel=0;
void airlines:: cancel_reservation()
{	int num;
	cout << "Please Enter your reservation Number here(the 4 digit number): ";
	cin >> num;

		node *cur = start;
		if(cur!=NULL)
		{

		if ( start->reserve_num == num )
		{
			node *del = start;
			start = start->next;
			delete del;
			seat[0] = 0;
			cancel++;
			return;
		}
		else
		{
			node *pre, *cur;
			pre = start;
			cur = start->next;
			while(cur != NULL)
			{
				if ( cur->reserve_num == num )
						break;
				pre = cur;
				cur = cur->next;
			}
			seat[cur->seat_num-1] = 0;
			if (cur != NULL )
			pre->next = cur->next;

		}

	cancel++;


		}
		else
		{
		cout<<"!!! *** Nothing to delete or invalid entry *** !!! \n"<<endl;
		}

}
//********************************************************************************************
void airlines:: check_ticket()
{
		int faketicket;
		cout << "Please enter your ticket that you want  to check here (place where u stay): ";
		cin >> faketicket;

		node *cur = start;
		while (cur != NULL)
		{
			if (cur->seat_num == faketicket)
			{
                    cout << "Reservation number: " <<" "<< cur->seat_num <<" "<<"is taken by"<<" "<<cur->fname<<" "<<cur->lname<<endl;

				return;
			}	cur = cur->next;
		}	cout << " Sorry!!! NOT FOUND \n\n";

}



//********************************************************************************************
void airlines:: print_list()
{
	temp=start;
	if(temp == NULL)
	cout<<" No passangers found"<<endl;
	else
	{	int cnt = 1;
		cout << "\tNumber\t First Name\t Last Name\t ID\t";
		cout << "Phone Number\t Seat Number\t Reservation No\n";

		while(temp != NULL)
		{
			cout << "\t" << cnt <<setw(15);
			cout << temp->fname <<setw(15);
			cout << temp->lname << setw(12);
			cout << temp->ID << setw(12);
			cout << temp->phone_num <<setw(15);
			cout << temp->seat_num <<setw(15);
			cout << temp->reserve_num <<setw(12);
            cout<<"\n";

			temp=temp->next;
			cnt++;
		}

            cout << "\n\n";
	}
}
//********************************************************************************************







